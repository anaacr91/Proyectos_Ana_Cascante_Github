import { Component, OnInit } from '@angular/core';
import { Hero } from '../hero';
import { HEROES } from '../mock-heroes';
import { HeroService } from '../hero.service';
import { MessageService } from '../message.service';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-heroes',
  templateUrl: './heroes.component.html',
  styleUrls: ['./heroes.component.css']
})
export class HeroesComponent implements OnInit {

  
  heroes: Hero[];
  selectedHero: Hero;

  constructor(private heroService: HeroService, private messageService: MessageService) {
    this.heroes = HEROES; // Asigna los héroes al array
    this.selectedHero = this.heroes[0]; // Asigna el primer héroe a selectedHero
  }
  

  ngOnInit() {
    this.getHeroes();
  }

  onSelect(hero: Hero): void {//obtiene un hero del tipo Hero
  this.selectedHero = hero;
  this.messageService.add(`Hero selected: ${hero.name}`);
}

getHeroes(): void {
  this.heroService.getHeroes();
  
}


}
